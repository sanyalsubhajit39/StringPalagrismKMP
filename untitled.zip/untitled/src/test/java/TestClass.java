
import Operation.getTaskOperation;

import Operation.postTaskOperation;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(Listener.class)
public class TestClass {
    Logger log = extentController.log;
    ExtentReports extent = extentController.extent;
    @Test (priority = 1)
    void notificationcheck() {
        ExtentTest regUserTest = extent.createTest("CHECKING NOTIFICATION");
        getTaskOperation op = new getTaskOperation(extentController.baseUrl+"/notification",  regUserTest,extentController.log);
        assert (op.checknotify()==true);
    }
    @Test (priority = 2)
    void getTrackResAllcheck() {
        ExtentTest regUserTest = extent.createTest("17. Get track results of all linkers");
        getTaskOperation op = new getTaskOperation(extentController.baseUrl+"/track-result",  regUserTest,extentController.log);
        assert (op.getTrackResAll()==true);
    }
    @Test (priority = 3)
    void getTrackResEmailcheck() {
        ExtentTest regUserTest = extent.createTest("18. Get result of a particular linker by email.");
        getTaskOperation op = new getTaskOperation(extentController.baseUrl+"/track-result/",  regUserTest,extentController.log);
        assert (op.getTrackResEmail()==true);
    }
    @Test (priority = 4)
    void getTrackAllocationAllcheck() {
        ExtentTest regUserTest = extent.createTest("19. Get all the tracks allocated to linkers.");
        getTaskOperation op = new getTaskOperation(extentController.baseUrl+"/track-allocated",  regUserTest,extentController.log);
        assert (op.getTrackAllocationAll()==true);
    }
    @Test (priority = 5)
    void getTrackAllocationEmailcheck() {
        ExtentTest regUserTest = extent.createTest("20. Get track allocated to a particular linker through email.");
        getTaskOperation op = new getTaskOperation(extentController.baseUrl+"/track-allocated/email/",  regUserTest,extentController.log);
        assert (op.getTrackAllocationEmail()==true);
    }
    @Test (priority = 6)
    void getInOneTrackAllcheck() {
        ExtentTest regUserTest = extent.createTest("21. Get all the linkers in a particular track.");
        getTaskOperation op = new getTaskOperation(extentController.baseUrl+"/track-allocated/track/Advance%20Angular",  regUserTest,extentController.log);
        assert (op.getInOneTrackAll()==true);
    }
    @Test (priority = 6)
    void postParallelTrackPrefcheck() {
        ExtentTest regUserTest = extent.createTest("22. Post parallel track preference");
        postTaskOperation op = new postTaskOperation(extentController.baseUrl+"/parallelpref-upload",  regUserTest,extentController.log);
        assert (op.postParallelTrackPref()==true);
    }

}