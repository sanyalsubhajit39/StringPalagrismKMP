
import Operation.TaskOperation;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

@Listeners(Listener.class)
public class TestClass {
    Logger log = extentController.log;
    ExtentReports extent = extentController.extent;
    @Test (priority = 1)
    void notificationcheck() {
        ExtentTest regUserTest = extent.createTest("CHECKING NOTIFICATION");
        TaskOperation op = new TaskOperation(extentController.baseUrl+"/notification",  regUserTest,extentController.log);
        op.checknotify();
    }

}