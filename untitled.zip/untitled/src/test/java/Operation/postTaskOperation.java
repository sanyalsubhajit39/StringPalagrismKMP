package Operation;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.apache.logging.log4j.Logger;

import static io.restassured.RestAssured.given;

public class postTaskOperation {
    ExtentTest test;
    Logger log;
    String baseUrl;
    RequestSpecification requestSpecification;
    ResponseSpecification responseSpecification;
    public postTaskOperation(String baseUrl,ExtentTest test, Logger log ) {
        RestAssured.useRelaxedHTTPSValidation();
        this.test = test;
        this.log = log;
        this.baseUrl = baseUrl;
        System.out.println(baseUrl);

        RequestSpecBuilder reqBuilder = new RequestSpecBuilder();
        reqBuilder.setBaseUri(baseUrl).addHeader("Content-Type", "text/html");
        requestSpecification = RestAssured.with().spec(reqBuilder.build());

        ResponseSpecBuilder resBuilder = new ResponseSpecBuilder();
        resBuilder.expectContentType(ContentType.HTML);
        responseSpecification = resBuilder.build();
    }
    public boolean postParallelTrackPref() {
        log.info("Post parallel track preference");
        test.info("Post parallel track preference");
        String bdy=getTaskOperation.getTrackAllocationJSON().toString();
        test.debug(bdy);
        try{
            Response response = given().spec(requestSpecification).body(bdy).post().then().
                    spec(responseSpecification).extract().response();


            if (response.getStatusCode()!=201){
                log.debug("Request Failed");
                test.info("Status Code: "+String.valueOf(response.getStatusCode()));
                test.fail("Request Failed");
                return false;
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
        log.info("User successfully registered");
        test.log(Status.PASS, "User successfully registered");
        return true;
    }
}

