package Operation;

import Helper.JSONParser;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static io.restassured.RestAssured.given;

public class TaskOperation  {
    private RequestSpecification requestSpecification;
    private ResponseSpecification responseSpecification;
    private List<String> tasks;
    private JSONArray tasksJsonArray;
    public String token="1e3fbfc04d510423f16db6b1976f8d49a339e4e486ef5006ebe118b552a2a32", baseUrl;
    public ExtentTest test;
    public Logger log;

    public TaskOperation(String baseUrl, ExtentTest test, Logger log) {
        RestAssured.useRelaxedHTTPSValidation();
        this.baseUrl = baseUrl;
        this.test = test;
        this.log = log;
        RestAssured.baseURI=baseUrl;
        requestSpecification = RestAssured.given();
        RequestSpecBuilder reqBuilder = new RequestSpecBuilder();
        reqBuilder.setBaseUri(baseUrl).addHeader("Content-Type", "application/json");
        requestSpecification = RestAssured.with().spec(reqBuilder.build());

        ResponseSpecBuilder resBuilder = new ResponseSpecBuilder();
        resBuilder.expectContentType(ContentType.JSON);
        responseSpecification = resBuilder.build();
    }

    public void checknotify() {
        test.info("Getting users data from , " + baseUrl);
        log.info("Getting users data from , " + baseUrl);
        // start HTTP GET to get an entry
        try{
            Response response=given().spec(requestSpecification)
                    .when().get().then().spec(responseSpecification)
                    .extract().response();

            JSONObject obj = new JSONObject(response.asString());
            tasksJsonArray = new JSONArray(obj.getJSONArray("data"));
            System.out.println(tasksJsonArray);
        }
        catch (Exception e){
            log.debug("Request Failed");
            test.fail("Request Failed");
        }
        log.debug("Fetched data");
        test.pass("Successfully fetched JSON ");
    }}


