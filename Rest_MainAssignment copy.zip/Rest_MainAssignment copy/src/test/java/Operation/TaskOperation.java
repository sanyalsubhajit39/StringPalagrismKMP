package Operation;

import Helper.ExtractData;
import Helper.JSONParser;
import Helper.User;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static io.restassured.RestAssured.given;

public class TaskOperation  {
    private RequestSpecification requestSpecification;
    private ResponseSpecification responseSpecification;
    private List<String> tasks;
    private JSONArray tasksJsonArray;
    public String token="1e3fbfc04d510423f16db6b1976f8d49a339e4e486ef5006ebe118b552a2a32", baseUrl;
    public ExtentTest test;
    public Logger log;
    public TaskOperation(String baseUrl, ExtentTest test, Logger log) {
        RestAssured.useRelaxedHTTPSValidation();
        this.baseUrl = baseUrl;
        this.test = test;
        this.log = log;
        RequestSpecBuilder reqBuilder = new RequestSpecBuilder();
        reqBuilder.setBaseUri(baseUrl).addHeader("Content-Type", "application/json");
        requestSpecification = RestAssured.with().spec(reqBuilder.build());

        ResponseSpecBuilder resBuilder = new ResponseSpecBuilder();
        resBuilder.expectContentType(ContentType.JSON);
        responseSpecification = resBuilder.build();
    }

    public void getResponseVerify() {
        test.info("Getting users data from , " + baseUrl);
        log.info("Getting users data from , " + baseUrl);
        // start HTTP GET to get an entry
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(baseUrl);
        httpGet.addHeader("Authorization", "AR-JWT " + token);
        try (CloseableHttpResponse response = httpClient.execute(httpGet)) {

            HttpEntity entity = response.getEntity();
            String jsonEntry = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(jsonEntry);
            tasksJsonArray = new JSONArray(obj.getJSONArray("data"));

        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.debug("Fetched data");
        test.pass("Successfully fetched JSON ");
    }

    public void getVerifyGender() {
        test.info("Verifying users gender data from , " + baseUrl);
        log.info("Verifying users gender data from , " + baseUrl);
        // start HTTP GET to get an entry
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(baseUrl);
        httpGet.addHeader("Authorization", "AR-JWT " + token);
        try (CloseableHttpResponse response = httpClient.execute(httpGet)) {

            HttpEntity entity = response.getEntity();
            String jsonEntry = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(jsonEntry);
            tasksJsonArray = new JSONArray(obj.getJSONArray("data"));
            boolean gender_enum_ok=true;
            boolean uid_unique=true;
            ArrayList<Integer> uid_store = new ArrayList<Integer>(tasksJsonArray.length());
            for(int i=0;i<tasksJsonArray.length();i++){
                System.out.println(tasksJsonArray.getJSONObject(i));
                if(tasksJsonArray.getJSONObject(i).getString("gender").equals("female")==false && tasksJsonArray.getJSONObject(i).getString("gender").equals("male")==false) {
                    gender_enum_ok = false;
                    test.fail("Gender not only MALE or FEMALE");
                    break;
                }
            }

        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.debug("Fetched gender data");
        test.pass("Successfully verified gender consistency from JSON ");
    }
    public void getVerifyUnique_id() {
        test.info("Verifying users with Unique ID data from , " + baseUrl);
        log.info("Verifying users with Unique ID data from , " + baseUrl);
        // start HTTP GET to get an entry
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(baseUrl);
        httpGet.addHeader("Authorization", "AR-JWT " + token);
        try (CloseableHttpResponse response = httpClient.execute(httpGet)) {

            HttpEntity entity = response.getEntity();
            String jsonEntry = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(jsonEntry);
            tasksJsonArray = new JSONArray(obj.getJSONArray("data"));
            boolean gender_enum_ok=true;
            boolean uid_unique=true;
            ArrayList<Integer> uid_store = new ArrayList<Integer>(tasksJsonArray.length());
            for(int i=0;i<tasksJsonArray.length();i++){
                System.out.println(tasksJsonArray.getJSONObject(i));

                if(uid_store.contains(tasksJsonArray.getJSONObject(i).getInt("id"))){
                    uid_unique=false;
                    //test.fail("UID not unique");
                    break;
                }
                else
                    uid_store.add(tasksJsonArray.getJSONObject(i).getInt("id"));
            }
            int max_uid=Collections.max(uid_store);
            new User(max_uid);


        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.debug("Fetched UID data");
        test.pass("Successfully verified UIDs are unique from JSON ");
    }


    public boolean post_alreadyPresentUser() {
        test.info("Posting already present mail-id , " + baseUrl);
        log.info("Posting already present mail-id , " + baseUrl);
        // start HTTP GET to get an entry
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(baseUrl);
        httpGet.addHeader("Authorization", "AR-JWT " + token);
        try (CloseableHttpResponse response = httpClient.execute(httpGet)) {

            HttpEntity entity = response.getEntity();
            String jsonEntry = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            JSONObject obj = new JSONObject(jsonEntry);
            tasksJsonArray = new JSONArray(obj.getJSONArray("data"));
            System.out.println("Posting"+tasksJsonArray.getJSONObject(0).toString());
            log.debug("Posting"+tasksJsonArray.getJSONObject(0).toString());
            Response response1 = given().spec(requestSpecification).header("Authorization", "Bearer " + token)
                    .body(tasksJsonArray.getJSONObject(0).toString()).post().then().
                    spec(responseSpecification).extract().response();
            if (response1.statusCode() == 401) {
                log.debug(response1.statusCode());
                String msg = "User already present with same email i.e. " ;
                log.warn(msg);
                test.warning(msg);
                test.fail("User already present with same email i.e.");
                return false;
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.debug("Fetched UID data");
        test.pass("Successfully verified UIDs are unique from JSON ");
        return true;
    }
}
